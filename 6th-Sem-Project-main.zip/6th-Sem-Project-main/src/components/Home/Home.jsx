import React from "react";
import Map from "../Map/Map";
import SimpleMap from "../Map/SimpleMap";
import MapWithCustomMaker from "../Map/MapWithCustomMarker";
import MultipleUserMap from "../Map/MultipleUserMap";
import { useSelector } from "react-redux";
function Home() {

  return (
    <div>
<MultipleUserMap/>
      
    </div>
  );
}
export default Home;
